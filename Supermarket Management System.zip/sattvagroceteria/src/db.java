
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author tanus
 */
public class db {
    
  public static Connection mycon(){
  
  
     Connection con = null;
  
     try{
         
        Class.forName("com.mysql.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3307/sattvagroceteria","root","12345678");
        return con;
         
     }catch(ClassNotFoundException | SQLException e){
         
         System.out.println(e);
         return null;
      }
  }  
    

}    
